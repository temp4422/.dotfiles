keyboard.press_key('<super>')
keyboard.press_key('<left>')
keyboard.release_key('<left>')
keyboard.release_key('<super>') 
