keyboard.press_key('<super>')
keyboard.press_key('<up>')
keyboard.release_key('<up>')
keyboard.release_key('<super>') 
