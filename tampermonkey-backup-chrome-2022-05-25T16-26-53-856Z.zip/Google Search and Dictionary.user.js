// ==UserScript==
// @name         Google Search and Dictionary
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.google.com/*
// @grant        none
// ==/UserScript==


(function() {
    'use strict';


    // Focus Google Search
//    window.addEventListener("keyup", checkKey0, false);
//    function checkKey0(key) {
//        if (key.key == '/' || key.key == '.' ) {
//            var x = document.querySelector('.gLFyf')
//            x.focus()
//            x.select()
//
//        }
//    }

    // Trigger Listen button on Dictionary page
//    window.addEventListener("keydown", checkKey2, false);
//    function checkKey2(key) {
//        if (key.key == 'q' && key.ctrlKey) {
//            var x = document.querySelector('div.brWULd')
//            x.click()
//        }
//    }

    // Focus Google Dictionary box
//    window.addEventListener("keydown", checkKey1, false);
//    function checkKey1(key) {
//        if (key.key == 'q' && key.ctrlKey) {
//            var box = document.querySelector('.dw-sbi')
//            box.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, keyCode: 13 })); // Send "Enter" key
//            box.focus()
//            box.select()
//        }
//    }

    window.addEventListener("keydown", checkKey, false);
    async function checkKey(thisKey) {
        let box = document.querySelector('.dw-sbi')
        let speaker = document.querySelector('div.brWULd')
        let enter = (new KeyboardEvent('keydown', { bubbles: true, keyCode: 13 }));
        function sleep(ms) {return new Promise(resolve => setTimeout(resolve, ms));}

        if (thisKey.key == 'q' && thisKey.ctrlKey) {
            //box.dispatchEvent(enter)
            //await sleep(500)
            speaker.click()
            await sleep(500)
            box.focus()
            box.select()
            //console.log("Greetings my friend! Good Work! ")
        }
    }




})();