// ==UserScript==
// @name         YouTube
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.youtube.com/watch*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Control YouTube playback speed with "Video speed controls" chrome extentsion
    window.addEventListener("keydown", checkKey0, false);
    function checkKey0(key) {
        if (key.key == '>') {
            // Simulate key press using standard KeyboardEvent https://stackoverflow.com/questions/3276794/jquery-or-pure-js-simulate-enter-key-pressed-for-testing/18937620#18937620
            const ke = new KeyboardEvent('keydown', {
            bubbles: true, cancelable: true, keyCode: 68 // Character "d" https://www.w3.org/2002/09/tests/keys.html
            });
            document.body.dispatchEvent(ke);
        }
        if (key.key == '<') {
            const ke = new KeyboardEvent('keydown', {
            bubbles: true, cancelable: true, keyCode: 83 // Character "s" https://www.w3.org/2002/09/tests/keys.html
            });
            document.body.dispatchEvent(ke);
        }
    }

})();