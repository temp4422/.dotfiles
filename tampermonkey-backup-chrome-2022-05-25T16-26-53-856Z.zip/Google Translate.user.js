// ==UserScript==
// @name         Google Translate
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://translate.google.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';


    // Trigger Listen button
    let xButton = document.querySelector('.tmJved'); // button class
    window.addEventListener('keydown', pressKey, false);
    function pressKey(x) {
        if (x.key == 'q' && x.ctrlKey || x.key == 'й' && x.ctrlKey) {
            xButton.click();
            setTimeout( function() {
                xBox.focus();
                xBox.select();
            }, 350);
            // xButton.style.backgroundColor = "green";
            // setTimeout( function() { xButton.style.backgroundColor = ""}, 500);
        }
    }


    // Focus search box
    let xBox = document.querySelector('.er8xn'); // textarea class
    window.addEventListener('keydown', pressKey2, false);
    function pressKey2(x) {
        if (x.key == '/') {
            setTimeout( function() {
                xBox.focus();
                xBox.select();
            }, 250);
        }
    }



})();