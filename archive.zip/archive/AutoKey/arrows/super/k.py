keyboard.press_key('<super>')
keyboard.press_key('<down>')
keyboard.release_key('<down>')
keyboard.release_key('<super>') 
