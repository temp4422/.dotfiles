keyboard.press_key('<super>')
keyboard.press_key('<right>')
keyboard.release_key('<right>')
keyboard.release_key('<super>') 
