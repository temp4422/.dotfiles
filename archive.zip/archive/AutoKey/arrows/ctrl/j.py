keyboard.send_keys('<ctrl>+<left>')
